﻿#include <SFML/Graphics.hpp>
#include <functional>
#include <cmath>
#include <windows.h>
using namespace sf;



// Функция для отрисовки графика
void drawGraph(RenderWindow& window, std::function<float(float)> func,
    float xMin, float xMax, float scaleX, float scaleY, Color color) {
    VertexArray graph(LinesStrip);

    for (float x = xMin; x <= xMax; x += 0.1f) {
        float y = func(x);                 // вычисление значения функции

        float screenX = 400 + x * scaleX;  // преобразование координат в экранные
        float screenY = 300 - y * scaleY;

        graph.append(Vertex(Vector2f(screenX, screenY), color));
    }

    window.draw(graph);
}

int main() {

    std::wstring zone = L"";

    RenderWindow window(VideoMode(800, 600), L"Приложение для вывода графиков");

    CircleShape userPoint(5);          // пользовательская точка, радиус 5 пикселей
    userPoint.setFillColor(Color::Red);
    bool userPointExists = false;

    // 1 _ Загрузка шрифта (допишите код)
    Font font;                                   // шрифт для счёта
    if (!font.loadFromFile("Comfortaa-Bold.ttf")) {
        return -1;
    }

    // 2 _ Текст для отображения координат: размер 20, позиция (10,10), цвет белый,
    //     переменная coordinatesText (допишите код)
    Text coordinatesText;
    coordinatesText.setFont(font);
    coordinatesText.setCharacterSize(20);
    coordinatesText.setFillColor(Color::White);
    coordinatesText.setPosition(10, 10);

    // Оси X и Y
    VertexArray xAxis(Lines, 2);
    xAxis[0].position = Vector2f(50, 300);   xAxis[0].color = Color::White;
    xAxis[1].position = Vector2f(750, 300);  xAxis[1].color = Color::White;
    VertexArray yAxis(Lines, 2);
    yAxis[0].position = Vector2f(400, 50);   yAxis[0].color = Color::White;
    yAxis[1].position = Vector2f(400, 550);  yAxis[1].color = Color::White;

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed)
                window.close();

            if (event.type == Event::MouseButtonPressed) {
                if (event.mouseButton.button == Mouse::Left) {
                    Vector2i mousePos = Mouse::getPosition(window);

                    // Преобразование экранных координат в «математические»
                    float mathX = (mousePos.x - 400) / 30.0f;
                    float mathY = -(mousePos.y - 300) / 100.0f;

                    userPoint.setPosition(mousePos.x - userPoint.getRadius(),
                        mousePos.y - userPoint.getRadius());
                    userPointExists = true;

                    // 3 _ Допишите логику проверки точки по mathX и mathY!
                    if (mathY == 6 * mathX || mathY == 4 * mathX + 8) {
                        zone = L"Граница";
                    } else if (mathY <= 6 * mathX && mathY <= 4 * mathX + 8) {
                        zone = L"Первая";
                    } else if (mathY >= 6 * mathX && mathY >= 4 * mathX + 8) {
                        zone = L"Вторая";
                    } else if (mathY >= 6 * mathX && mathY <= 4 * mathX + 8) {
                        zone = L"Третья";
                    } else if (mathY <= 6 * mathX && mathY >= 4 * mathX + 8) {
                        zone = L"Четвёртая";
                    } else {
                        zone = L"Ошибка от Komaru";
                    }


                    coordinatesText.setString("Coordinates: (" + std::to_string(mathX) +
                        ", " + std::to_string(mathY) + "), " + zone + ")");
                }
            }
        }

        // 4 _ Очистка экрана (допишите код)
        window.clear();

        window.draw(xAxis);
        window.draw(yAxis);

        // 5 _ Замените на графики вашего варианта
        drawGraph(window, [](float x) { return 6 * x; }, -10, 10, 30, 100, Color::Blue);
        drawGraph(window, [](float x) { return 4 * x + 8; }, -10, 10, 30, 100, Color::Red);

        if (userPointExists) {
            window.draw(userPoint);
            window.draw(coordinatesText);
        }

        window.display();
    }

    return 0;
}